# xpedition_manager/__init__.py
from .manager import XpeditionManager